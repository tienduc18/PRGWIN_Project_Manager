﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyDoAn.ViewModel
{
    public class ChuyenNganhViewModel
    {
        public string IDChuyenNganh { get; set; }
        public string TenChuyenNganh { get; set; }
    }
}
